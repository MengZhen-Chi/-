//
//  OrderModel.m
//  demo-ios
//
//  Created by Bob on 2022/7/28.
//

#import "OrderModel.h"

@implementation OrderModel

@end
