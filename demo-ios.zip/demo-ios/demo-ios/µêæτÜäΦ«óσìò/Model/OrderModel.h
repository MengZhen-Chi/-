//
//  OrderModel.h
//  demo-ios
//
//  Created by Bob on 2022/7/28.
//

#import <Foundation/Foundation.h>
#import "TicketModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OrderModel : NSObject

// 订单id
@property (nonatomic,copy) NSString *orderid;
// 创建时间
@property (nonatomic,copy) NSString *creatTime;
// 车票状态 1 未使用 2 已使用
@property (nonatomic,copy) NSString *status;
// 车票信息
@property (nonatomic,strong) TicketModel *ticket;

@end

NS_ASSUME_NONNULL_END
