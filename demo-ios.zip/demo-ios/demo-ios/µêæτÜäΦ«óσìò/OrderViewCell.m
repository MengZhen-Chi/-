#import "OrderViewCell.h"
#import "OrderModel.h"

@interface OrderViewCell() 
@property (weak, nonatomic) IBOutlet UILabel *startCity;
@property (weak, nonatomic) IBOutlet UILabel *endCity;
@property (weak, nonatomic) IBOutlet UILabel *remainL;
@property (weak, nonatomic) IBOutlet UIButton *buyButton;

@end

@implementation OrderViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
// 设置model
- (void)setModel:(OrderModel *)model {
    _model = model;
    self.startCity.text = model.ticket.startCity;
    self.endCity.text = model.ticket.endCity;
    self.remainL.text = model.creatTime;
    if ([model.status isEqualToString:@"1"]) {
        [self.buyButton setTitle:@"待使用" forState:UIControlStateNormal];
        [self.buyButton setBackgroundColor:[UIColor orangeColor]];
    } else {
        [self.buyButton setTitle:@"已使用" forState:UIControlStateNormal];
        [self.buyButton setBackgroundColor:[UIColor lightGrayColor]];
    }
}
// 点击使用
- (IBAction)buyClick:(UIButton *)sender {
    if ([self.buyButton.titleLabel.text isEqualToString:@"待使用"]) {
        [self.buyButton setTitle:@"已使用" forState:UIControlStateNormal];
        [self.buyButton setBackgroundColor:[UIColor lightGrayColor]];
        if (self.orderViewCellClick) {
            self.orderViewCellClick(self.model);
        }
    }
    
}


@end
