#import "MineViewController.h"
#import "OrderViewCell.h"
#import "AppDelegate.h"

@interface MineViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *dataArray;
@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"我的订单";
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    // 注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"OrderViewCell" bundle:nil] forCellReuseIdentifier:@"OrderViewCell"];
    self.dataArray = [AppDelegate shareAppDelegate].comDict[@"order"];
    [self.tableView reloadData];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    OrderViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderViewCell"];
    cell.model = self.dataArray[indexPath.row];
    cell.orderViewCellClick = ^(OrderModel * _Nonnull model) {
        [self userTicket:model];
    };
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}
// 消费车票，去乘车
- (void)userTicket:(OrderModel *)model {
    NSMutableArray *order = [AppDelegate shareAppDelegate].comDict[@"order"];
    // 遍历所有的订单
    for (int i = 0; i < order.count; i ++) {
        OrderModel *tempModel = order[i];
        //找到当前订单，改变订单中车票的状态
        if ([model.orderid isEqualToString:tempModel.orderid]) {
            tempModel.status = @"2";
        }
    }
    // 修改完成之后，把修改后的数据设置为全局引用
    [AppDelegate shareAppDelegate].comDict[@"order"] = order;
    self.dataArray = [AppDelegate shareAppDelegate].comDict[@"order"];
    // 刷新列表
    [self.tableView reloadData];
}
- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
@end
