#import <UIKit/UIKit.h>
#import "OrderModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OrderViewCell : UITableViewCell

@property (nonatomic,strong) OrderModel *model;
@property (nonatomic, copy) void(^orderViewCellClick)(OrderModel *model);

@end

NS_ASSUME_NONNULL_END
