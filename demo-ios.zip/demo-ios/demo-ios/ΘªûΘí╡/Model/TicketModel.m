#import "TicketModel.h"

@implementation TicketModel

@end
