#import <UIKit/UIKit.h>
#import "TicketModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeViewCell : UITableViewCell

@property (nonatomic,strong) TicketModel *model;
@property (nonatomic, copy) void(^HomeViewCellClick)(TicketModel *model);

@end

NS_ASSUME_NONNULL_END
