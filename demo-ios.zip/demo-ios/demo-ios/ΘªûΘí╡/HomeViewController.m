#import "HomeViewController.h"
#import "HomeViewCell.h"
#import "MineViewController.h"
#import "TicketModel.h"
#import "AppDelegate.h"
#import "OrderModel.h"

@interface HomeViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *dataArray;
@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"首页";
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    // 注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"HomeViewCell" bundle:nil] forCellReuseIdentifier:@"HomeViewCell"];
    
    UIBarButtonItem *mineBar = [[UIBarButtonItem alloc] initWithTitle:@"我的订单" style:UIBarButtonItemStylePlain target:self action:@selector(mineBarAction:)];
    self.navigationItem.rightBarButtonItem = mineBar;
    [self resetBarAction];
}

// 每次进来之后就初始化数据
- (void)resetBarAction {
    [self.dataArray removeAllObjects];
    NSArray *resetData = @[
        @{@"startCity": @"北京", @"endCity": @"上海", @"remainNum": @"20"},
        @{@"startCity": @"广州", @"endCity": @"南宁", @"remainNum": @"20"},
        @{@"startCity": @"昆明", @"endCity": @"厦门", @"remainNum": @"20"},
        @{@"startCity": @"郑州", @"endCity": @"西安", @"remainNum": @"20"},
        @{@"startCity": @"兰州", @"endCity": @"拉萨", @"remainNum": @"20"},
        @{@"startCity": @"大理", @"endCity": @"天津", @"remainNum": @"20"},
    ];
    
    for (int i = 0; i < resetData.count; i ++) {
        NSDictionary *dict = resetData[i];
        // 把数组中的数据转为类
        TicketModel *model = [[TicketModel alloc] init];
        model.ticketid = [NSString stringWithFormat:@"%d", i];
        model.startCity = dict[@"startCity"];
        model.endCity = dict[@"endCity"];
        model.remainNum = [dict[@"remainNum"] intValue];
        [self.dataArray addObject:model];
    }
    [self.tableView reloadData];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    dict[@"ticket"] = self.dataArray;
    dict[@"order"] = @[];
    // 设置全局引用
    [AppDelegate shareAppDelegate].comDict= dict;
}

- (void)mineBarAction:(UIBarButtonItem *)btn {
    MineViewController *mine = [[MineViewController alloc] init];
    [self.navigationController pushViewController:mine animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HomeViewCell"];
    cell.model = self.dataArray[indexPath.row];
    cell.HomeViewCellClick = ^(TicketModel * _Nonnull model) {
        [self buyTicket:model];
    };
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}
// 购买车票
- (void)buyTicket:(TicketModel *)model {
    NSMutableArray *ticket = [AppDelegate shareAppDelegate].comDict[@"ticket"];
    NSMutableArray *order = [NSMutableArray arrayWithArray:[AppDelegate shareAppDelegate].comDict[@"order"]];
    // 遍历所有车票信息
    for (int i = 0; i < ticket.count; i ++) {
        TicketModel *tempModel = ticket[i];
        // 找到要购买的那列车票
        if ([model.ticketid isEqualToString:tempModel.ticketid]) {
            // 如果这列车票余额为0，那么余额就-1
            if (tempModel.remainNum > 0) {
                tempModel.remainNum -= 1;
                OrderModel *orderM = [[OrderModel alloc] init];
                orderM.orderid = [NSString stringWithFormat:@"%lu", (order.count + 1)];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
                NSDate *datenow = [NSDate date];
                NSString *currentTimeString = [formatter stringFromDate:datenow];
                orderM.creatTime = currentTimeString;
                orderM.status = @"1";
                orderM.ticket = tempModel;
                [order addObject:orderM];
            } else {
                // 如果余额为0，提示
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"目前余票为0" preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *sure = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        NSLog(@"确定");
                    }];
                [alert addAction:sure];
                [self presentViewController:alert animated:YES completion:nil];
            }
        }
    }
    // 修改完库存，在设置数据到全局
    [AppDelegate shareAppDelegate].comDict[@"ticket"] = ticket;
    [AppDelegate shareAppDelegate].comDict[@"order"] = order;
    self.dataArray = [AppDelegate shareAppDelegate].comDict[@"ticket"];
    [self.tableView reloadData];
}

- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

@end
