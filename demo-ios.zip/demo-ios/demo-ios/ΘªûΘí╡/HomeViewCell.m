#import "HomeViewCell.h"

@interface HomeViewCell() 
@property (weak, nonatomic) IBOutlet UILabel *startCity;
@property (weak, nonatomic) IBOutlet UILabel *endCity;
@property (weak, nonatomic) IBOutlet UILabel *remainL;
@property (weak, nonatomic) IBOutlet UIButton *buyButton;

@end

@implementation HomeViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

// 设置model
- (void)setModel:(TicketModel *)model {
    _model = model;
    self.startCity.text = model.startCity;
    self.endCity.text = model.endCity;
    self.remainL.text = [NSString stringWithFormat:@"%d张", model.remainNum];
}
// 购买车票
- (IBAction)buyClick:(id)sender {
    if (self.HomeViewCellClick) {
        self.HomeViewCellClick(self.model);
    }
}


@end
